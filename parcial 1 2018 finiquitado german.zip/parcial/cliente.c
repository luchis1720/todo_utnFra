#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <conio.h>
#include "cliente.h"
#include "utn.h"

/** \brief
 * \param arrayCliente ECliente*
 * \param limiteCliente int
 * \return int
 *
 */
int cliente_init(ECliente* arrayCliente,int limiteCliente)
{
    int retorno = -1;
    int i;
    if(limiteCliente > 0 && arrayCliente != NULL)
    {
        retorno = 0;
        for(i=0;i<limiteCliente;i++)
        {
            arrayCliente[i].isEmpty=1;
        }
    }
    return retorno;
}

int cliente_mostrarDebug(ECliente* arrayCliente,int limiteCliente)
{
    int retorno = -1;
    int i;
    if(limiteCliente > 0 && arrayCliente != NULL)
    {
        retorno = 0;
        for(i=0;i<limiteCliente;i++)
        {
            printf("[DEBUG] - %d - %s - %d\n",arrayCliente[i].idCliente, arrayCliente[i].nombre, arrayCliente[i].isEmpty);
        }
    }
    return retorno;
}

int cliente_mostrar(ECliente* arrayCliente,int limiteCliente)
{
    int retorno = -1;
    int i;
    if(limiteCliente > 0 && arrayCliente != NULL)
    {
        retorno = 0;
        for(i=0;i<limiteCliente;i++)
        {
            if(!arrayCliente[i].isEmpty)
                printf("\n-ID: %d -Nombre: %s -Apellido %s -CUIT: %s \n",arrayCliente[i].idCliente, arrayCliente[i].nombre, arrayCliente[i].apellido,arrayCliente[i].cuit);
        }
    }
    return retorno;
}

int cliente_alta(ECliente* arrayCliente,int limiteCliente)
{
    int retorno = -1;
    int i;
    char auxNombre[51];
    char auxApellido[51];
    char auxCuit[12];
if(limiteCliente > 0 && arrayCliente != NULL)
    {
        i = buscarLugarLibre(arrayCliente,limiteCliente);
        if(i >= 0)
        {
            if(!getValidString("\nNombre? ","\nEso no es un nombre","\nEl maximo son 50 letras",auxNombre,51,2))
            {
                if(!getValidString("\nApellido? ", "\nApellido no valido","\nEl maximo son 50 letras",auxApellido,51,2))
                {
                        if(!cliente_getCuit("Ingrese su CUIT: ","(solo numeros)\n",auxCuit))
                        {
                            retorno = 0;
                            strcpy(arrayCliente[i].nombre, auxNombre);
                            strcpy(arrayCliente[i].apellido, auxApellido);
                            strcpy(arrayCliente[i].cuit, auxCuit);
                            arrayCliente[i].idCliente = proximoIdCliente();
                            arrayCliente[i].isEmpty = 0;
                            printf("\nDATOS CARGADOS\n");

                        }
                        else
                        {
                            retorno = -5;
                        }
                }
                else
                {
                    retorno = -4;
                }
            }
            else
            {
                retorno = -3;
            }
        }
        else
        {
            retorno = -2;
        }

    }
    return retorno;
}


int cliente_baja(ECliente* arrayCliente,int limiteCliente, int id)
{
    int retorno = -1;
    int i;
    if(cliente_verificarAlta(arrayCliente,limiteCliente))
    {
        if(limiteCliente > 0 && arrayCliente != NULL)
        {
            retorno = -2;
            if(!confirmacion("\nSeguro desea eliminar este usuario?\n"))
            {
                for(i=0;i<limiteCliente;i++)
                {

                    if(!arrayCliente[i].isEmpty && arrayCliente[i].idCliente==id)
                    {
                        arrayCliente[i].isEmpty = 1;
                        retorno = 0;
                        break;
                    }
                }
            }
        }
    }
    else
    {
        printf("\nERROR. Debe dar un alta primero.\n");
    }
    return retorno;
}




int cliente_modificacion(ECliente* arrayCliente,int limiteCliente, int id)
{
    int retorno = -1; // null exception
    int i;
    char auxNombre[51];
    char auxApellido[51];
    char auxCuit[12];
    if(cliente_verificarAlta(arrayCliente,limiteCliente))
    {
        if(limiteCliente > 0 && arrayCliente != NULL)
        {
            for(i=0; i<limiteCliente; i++)
            {
                if(!arrayCliente[i].isEmpty && arrayCliente[i].idCliente==id)
                {
                    if(!getValidString("\nNombre? ","\nEso no es un nombre","\nEl maximo son 50 letras",auxNombre,51,2))
                    {
                        if(!getValidString("\nApellido? ", "\nApellido no valido","\nEl maximo son 50 letras",auxApellido,51,2))
                        {
                            if(!cliente_getCuit("\nIngrese su cuit: ","CUIT INVALIDO\n",auxCuit))
                            {
                                retorno = 0;
                                strcpy(arrayCliente[i].nombre, auxNombre);
                                strcpy(arrayCliente[i].apellido, auxApellido);
                                strcpy(arrayCliente[i].cuit,auxCuit);
                                arrayCliente[i].isEmpty = 0;
                                break;

                            }
                            else
                            {
                                retorno = -5; // cuit invalido
                            }
                        }
                        else
                        {
                            retorno = -4; //apellido invalido
                        }
                    }
                    else
                    {
                        retorno = -3; //nombre invalido
                    }
                }
                else
                {
                    retorno = -2; //no existe cliente
                }
            }
        }
    }
    else
    {
        printf("\nERROR DEBE CARGAR UN CLIENTE PRIMERO\n");
    }

    return retorno;
}

int cliente_ordenarPorCuit(ECliente* arrayCliente,int limiteCliente, int orden)
{
    int retorno = -1;
    int i;
    int flagSwap;
    ECliente auxiliarEstructura;
    if(cliente_verificarAlta(arrayCliente,limiteCliente))
    {
        if(limiteCliente > 0 && arrayCliente != NULL)
        {
            do
            {
                flagSwap = 0;
                for(i=0;i<limiteCliente-1;i++)
                {
                    if(!arrayCliente[i].isEmpty && !arrayCliente[i+1].isEmpty)
                    {
                        if((strcmp(arrayCliente[i].cuit,arrayCliente[i+1].cuit) > 0 && orden) || (strcmp(arrayCliente[i].cuit,arrayCliente[i+1].cuit) < 0 && !orden)) //******
                        {
                            auxiliarEstructura = arrayCliente[i];
                            arrayCliente[i] = arrayCliente[i+1];
                            arrayCliente[i+1] = auxiliarEstructura;
                            flagSwap = 1;
                        }
                    }
                }
            }while(flagSwap);
        }
    }
    else
    {
        printf("ERROR. Debe dar un alta primero.");
    }
    return retorno;
}


int buscarLugarLibre(ECliente* arrayCliente,int limiteCliente)
{
    int retorno = -1;
    int i;
    if(limiteCliente > 0 && arrayCliente != NULL)
    {
        for(i=0;i<limiteCliente;i++)
        {
            if(arrayCliente[i].isEmpty==1)
            {
                retorno = i;
                break;
            }
        }
    }
    return retorno;
}

static int proximoId = -1;

int proximoIdCliente()
{
    proximoId++;
    return proximoId;
}

int cliente_verificarAlta(ECliente* arrayCliente, int limiteCliente)
{
    int i;
    int contador=0;

    for(i=0; i<limiteCliente; i++)
    {
        if(!arrayCliente[i].isEmpty)
        {
            contador++;
        }
    }
    return contador;
}

int cliente_getCuit(char* mensaje, char* mensajeError, char* input)
{
    char aux[256];
    getString(mensaje,aux);
    if(esNumerico(aux)&& (strlen(aux)==11 ))
    {
        strcpy(input,aux);
        return 0;
    }
    else
    {
        printf(mensajeError);
    }
    return 1;
}

int confirmacion(char* texto)
{
    char confirmar;

    printf("%s", texto);
    printf("\npresione ENTER para continuar o ESC para cancelar?\n\n");
    fflush(stdin);
    confirmar = getch();
    while (!(confirmar==27 || confirmar==13))
    {
        printf("\nERROR. presione ENTER para continuar o ESC para cancelar?\n\n");
        fflush(stdin);
        confirmar= getch();
    }
    if (confirmar!= 27 )
    {
        return 0;
    }
    else
    {
        printf("\nACCION CANCELADA POR EL USUARIO\n\n");
        return 1;
    }


}

/*int cliente_cantidadDeClientes(ECliente* arrayCliente, int limiteCliente)
{
  int i;
  int retorno =-1;
  int contadorClientes=0;
  if(cliente_verificarAlta(arrayCliente,limiteCliente))
  {
        cliente_ordenar(arrayCliente,limiteCliente,1);
        for(i=0;i<limiteCliente;i++)
        {
            if(strcmp(arrayCliente[i].cuit,arrayCliente[i+1].cuit)!=0 && !arrayCliente[i].isEmpty)
            {
                contadorClientes++;
            }
        }
  }
  else
  {
      printf("\nERROR. Debe dar un alta primero.\n");
  }

  return contadorClientes;
}
*/
















